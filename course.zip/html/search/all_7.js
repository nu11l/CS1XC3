var searchData=
[
  ['student_2ec_13',['student.c',['../student_8c.html',1,'']]]
];
