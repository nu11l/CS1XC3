var searchData=
[
  ['student_2ec_20',['student.c',['../student_8c.html',1,'']]]
];
